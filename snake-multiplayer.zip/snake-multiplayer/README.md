Jogo Snake Multiplayer - JRM 

npm install

node index.js

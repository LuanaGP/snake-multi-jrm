function Gameboard() {
	
	this.width = 24;
	this.height = 24;

	this.x = 0;
	this.y = 0;

	this.blockSize = 22;

	return this;
}

Gameboard.prototype = {
	render: function(context) {
		context.fillStyle = '#FFFFFF';
		context.fillRect(this.x, this.y, this.width * this.blockSize, this.height * this.blockSize);
	}
}
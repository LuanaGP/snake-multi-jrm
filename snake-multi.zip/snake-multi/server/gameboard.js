class Gameboard {
	constructor() {
		
		this.width = 24;
		this.height = 24;

		return this;
	}
}

module.exports = Gameboard;
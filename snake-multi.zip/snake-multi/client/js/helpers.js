var helpers = {
	fillRoundedRect: function(context, x, y, w, h, r){
		context.beginPath();
		context.moveTo(x+r, y);
		context.lineTo(x+w-r, y);
		context.quadraticCurveTo(x+w, y, x+w, y+r);
		context.lineTo(x+w, y+h-r);
		context.quadraticCurveTo(x+w, y+h, x+w-r, y+h);
		context.lineTo(x+r, y+h);
		context.quadraticCurveTo(x, y+h, x, y+h-r);
		context.lineTo(x, y+r);
		context.quadraticCurveTo(x, y, x+r, y);
		context.fill();
	},

	randomIntBetween: function(min, max) {
		return Math.floor(Math.random() * (max - min + 1) + min);
	},

	getAllUrlParams: function(url) {
	  
	  var queryString = url ? url.split('?')[1] : window.location.search.slice(1);
	  
	  var obj = {};
	  
	  if (queryString) {
	    queryString = queryString.split('#')[0];
	    var arr = queryString.split('&');
	    for (var i=0; i<arr.length; i++) {
	      var a = arr[i].split('=');
	      var paramNum = undefined;
	      var paramName = a[0].replace(/\[\d*\]/, function(v) {
	        paramNum = v.slice(1,-1);
	        return '';
	      });
	      var paramValue = typeof(a[1])==='undefined' ? true : a[1];
	      paramName = paramName.toLowerCase();
	      paramValue = paramValue.toLowerCase();
	      if (obj[paramName]) {
	        if (typeof obj[paramName] === 'string') {
	          obj[paramName] = [obj[paramName]];
	        }
	        if (typeof paramNum === 'undefined') {
	          obj[paramName].push(paramValue);
	        }
	        else {
	          obj[paramName][paramNum] = paramValue;
	        }
	      }
	      else {
	        obj[paramName] = paramValue;
	      }
	    }
	  }
	  return obj;
	}
}